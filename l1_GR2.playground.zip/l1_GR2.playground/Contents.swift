import UIKit

var s: Double = 0
var p: Double = 0
var g: Double = 0

let a: Double = 1
let b: Double = 4


s = (a*b) / 2
p = a+b+sqrt(a*a+b*b)
g = sqrt(a*a+b*b)

print("площадь \(s), периметр \(p), гипотенуза \(g)")
